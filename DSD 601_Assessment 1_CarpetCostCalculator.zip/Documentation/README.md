# Project Title - DSD 601 Software Development 2 - CarpetCostCalculator
# Project Description - In this assessment, I build a carpet cost calculator for the ATC Carpet Warehouse using a C# programming language. 
The company sells and installs a variety of carpets. They also offer additional services of installing high-quality 
underlay for their customers.  The company receives many phone inquiries about carpet costs, installation costs and 
underlay costs; therefore, they hired me to develop an easy to use cost calculator for their users.
You need to enter the room width and length, select carpet type, select an additional service option for installing the carpet, select an additional service option
for installing the underlay.After you select the type of carpet and service option, you will get the final
cost of the carpet.By using the different functionalities ie.under the code, I structured to utilise the concepts of
Object-oriented programming as below:
a)	A class Carpet holds all the properties of the carpet program such as Models and Operations class. 
b)	A class CarpetOperations, holds all the calculations needed such as installation and underlay.
As per the final cost calculation, it includes cost per squere meter and area of the carpet.
#Steps to run the program
1. Open CarpetCostCalculator.sln in visual studio 2022 
2. Click on green arrow to run the code and select the browser to run the code(Firefox,Edge etc).






